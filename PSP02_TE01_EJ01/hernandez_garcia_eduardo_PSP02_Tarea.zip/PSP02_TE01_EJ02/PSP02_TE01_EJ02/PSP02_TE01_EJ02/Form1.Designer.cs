﻿namespace PSP02_TE01_EJ02
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonEmpezar = new System.Windows.Forms.Button();
            this.buttonReiniciar = new System.Windows.Forms.Button();
            this.progressBarCaballo1 = new System.Windows.Forms.ProgressBar();
            this.labelCaballo1 = new System.Windows.Forms.Label();
            this.labelCaballo2 = new System.Windows.Forms.Label();
            this.progressBarCaballo2 = new System.Windows.Forms.ProgressBar();
            this.labelCaballo3 = new System.Windows.Forms.Label();
            this.progressBarCaballo3 = new System.Windows.Forms.ProgressBar();
            this.labelCaballo4 = new System.Windows.Forms.Label();
            this.progressBarCaballo4 = new System.Windows.Forms.ProgressBar();
            this.textBoxResultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonEmpezar
            // 
            this.buttonEmpezar.Location = new System.Drawing.Point(36, 12);
            this.buttonEmpezar.Name = "buttonEmpezar";
            this.buttonEmpezar.Size = new System.Drawing.Size(155, 72);
            this.buttonEmpezar.TabIndex = 0;
            this.buttonEmpezar.Text = "Empezar";
            this.buttonEmpezar.UseVisualStyleBackColor = true;
            this.buttonEmpezar.Click += new System.EventHandler(this.buttonEmpezar_Click);
            // 
            // buttonReiniciar
            // 
            this.buttonReiniciar.Location = new System.Drawing.Point(213, 12);
            this.buttonReiniciar.Name = "buttonReiniciar";
            this.buttonReiniciar.Size = new System.Drawing.Size(155, 72);
            this.buttonReiniciar.TabIndex = 1;
            this.buttonReiniciar.Text = "Reiniciar";
            this.buttonReiniciar.UseVisualStyleBackColor = true;
            this.buttonReiniciar.Click += new System.EventHandler(this.buttonReiniciar_Click);
            // 
            // progressBarCaballo1
            // 
            this.progressBarCaballo1.Location = new System.Drawing.Point(166, 146);
            this.progressBarCaballo1.Name = "progressBarCaballo1";
            this.progressBarCaballo1.Size = new System.Drawing.Size(625, 68);
            this.progressBarCaballo1.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBarCaballo1.TabIndex = 2;
            // 
            // labelCaballo1
            // 
            this.labelCaballo1.AutoSize = true;
            this.labelCaballo1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelCaballo1.Location = new System.Drawing.Point(55, 172);
            this.labelCaballo1.Name = "labelCaballo1";
            this.labelCaballo1.Size = new System.Drawing.Size(81, 21);
            this.labelCaballo1.TabIndex = 3;
            this.labelCaballo1.Text = "Caballo 1";
            // 
            // labelCaballo2
            // 
            this.labelCaballo2.AutoSize = true;
            this.labelCaballo2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelCaballo2.Location = new System.Drawing.Point(55, 277);
            this.labelCaballo2.Name = "labelCaballo2";
            this.labelCaballo2.Size = new System.Drawing.Size(81, 21);
            this.labelCaballo2.TabIndex = 5;
            this.labelCaballo2.Text = "Caballo 2";
            // 
            // progressBarCaballo2
            // 
            this.progressBarCaballo2.Location = new System.Drawing.Point(166, 251);
            this.progressBarCaballo2.Name = "progressBarCaballo2";
            this.progressBarCaballo2.Size = new System.Drawing.Size(625, 68);
            this.progressBarCaballo2.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBarCaballo2.TabIndex = 4;
            // 
            // labelCaballo3
            // 
            this.labelCaballo3.AutoSize = true;
            this.labelCaballo3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelCaballo3.Location = new System.Drawing.Point(55, 381);
            this.labelCaballo3.Name = "labelCaballo3";
            this.labelCaballo3.Size = new System.Drawing.Size(81, 21);
            this.labelCaballo3.TabIndex = 7;
            this.labelCaballo3.Text = "Caballo 3";
            // 
            // progressBarCaballo3
            // 
            this.progressBarCaballo3.Location = new System.Drawing.Point(166, 355);
            this.progressBarCaballo3.Name = "progressBarCaballo3";
            this.progressBarCaballo3.Size = new System.Drawing.Size(625, 68);
            this.progressBarCaballo3.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBarCaballo3.TabIndex = 6;
            // 
            // labelCaballo4
            // 
            this.labelCaballo4.AutoSize = true;
            this.labelCaballo4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelCaballo4.Location = new System.Drawing.Point(55, 475);
            this.labelCaballo4.Name = "labelCaballo4";
            this.labelCaballo4.Size = new System.Drawing.Size(81, 21);
            this.labelCaballo4.TabIndex = 9;
            this.labelCaballo4.Text = "Caballo 4";
            // 
            // progressBarCaballo4
            // 
            this.progressBarCaballo4.Location = new System.Drawing.Point(166, 449);
            this.progressBarCaballo4.Name = "progressBarCaballo4";
            this.progressBarCaballo4.Size = new System.Drawing.Size(625, 68);
            this.progressBarCaballo4.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBarCaballo4.TabIndex = 8;
            // 
            // textBoxResultado
            // 
            this.textBoxResultado.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBoxResultado.Location = new System.Drawing.Point(827, 146);
            this.textBoxResultado.Multiline = true;
            this.textBoxResultado.Name = "textBoxResultado";
            this.textBoxResultado.ReadOnly = true;
            this.textBoxResultado.Size = new System.Drawing.Size(164, 371);
            this.textBoxResultado.TabIndex = 10;
            this.textBoxResultado.TabStop = false;
            this.textBoxResultado.Text = "RESULTADO:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1034, 574);
            this.Controls.Add(this.textBoxResultado);
            this.Controls.Add(this.labelCaballo4);
            this.Controls.Add(this.progressBarCaballo4);
            this.Controls.Add(this.labelCaballo3);
            this.Controls.Add(this.progressBarCaballo3);
            this.Controls.Add(this.labelCaballo2);
            this.Controls.Add(this.progressBarCaballo2);
            this.Controls.Add(this.labelCaballo1);
            this.Controls.Add(this.progressBarCaballo1);
            this.Controls.Add(this.buttonReiniciar);
            this.Controls.Add(this.buttonEmpezar);
            this.Name = "Form1";
            this.Text = "Carrera de caballos - Eduardo Hernandez";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button buttonEmpezar;
        private Button buttonReiniciar;
        private ProgressBar progressBarCaballo1;
        private Label labelCaballo1;
        private Label labelCaballo2;
        private ProgressBar progressBarCaballo2;
        private Label labelCaballo3;
        private ProgressBar progressBarCaballo3;
        private Label labelCaballo4;
        private ProgressBar progressBarCaballo4;
        private TextBox textBoxResultado;

        //Array para guardar la distancia recorrida por cada caballo
        private int[] arrayAvance = { 0, 0, 0, 0 };

        //Objeto para el bloqueo
        private Object bloqueo = new Object();

        //Numero del caballo ganador
        private int ganador = -1;

        //Lista de hilos
        List<Thread> threads = new List<Thread>();

    }
}